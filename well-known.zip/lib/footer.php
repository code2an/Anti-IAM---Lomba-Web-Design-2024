    <footer class="footer-wrapper footer-2">
        <div class="footer-bottom-wrapper">
            <div class="container">
                <div class="footer-bottom-content d-md-flex justify-content-between">
                    <div class="site-copyright wow fadeInUp" data-wow-delay=".2" data-wow-duration="1s">
                        <p>&copy; 2024 <a href="#">Bumiara</a> All Rights Reserved.</p>
                    </div>
                    <div class="social-links mt-4 mt-md-0 gray-bg wow fadeInUp" data-wow-delay=".5" data-wow-duration="1s">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
